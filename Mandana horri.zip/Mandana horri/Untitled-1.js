var x=["5","6","7"];
var y=["10","11","12"];
console.log
document.write( Result );
 